[![License](https://img.shields.io/github/license/ezralazuardy/ChocoView.svg)](https://github.com/ezralazuardy/aplikasi-antrian-klinik/blob/master/LICENSE) [![Releases](https://img.shields.io/github/v/release/ezralazuardy/aplikasi-antrian-klinik?color=green)](https://github.com/ezralazuardy/aplikasi-antrian-klinik/releases)

## Aplikasi Antrian Klinik [DISCONTINUED]
Aplikasi untuk kepentingan manajemen klinik.<br>
Untuk membuka, tolong gunakan [Xampp](https://www.apachefriends.org/download.html) versi 5.x.x agar tidak terjadi kesalahan (pada library Mcrypt).


<i><b>Get the lastest update in [Branch Beta](https://github.com/ezralazuardy/aplikasi-antrian-klinik/tree/beta).</b></i>
