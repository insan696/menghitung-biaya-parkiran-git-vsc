<?php
class C_TentangAplikasi extends CI_Controller {
	public function index() {
		$this->load->view("V_TentangAplikasi");
	}
}
